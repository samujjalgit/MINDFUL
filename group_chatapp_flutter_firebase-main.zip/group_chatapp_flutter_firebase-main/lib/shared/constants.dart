import 'package:flutter/material.dart';

class Constants {
  static String appId = "1:634480644405:web:5549258ea987afaefb7c7c";
  static String apiKey = "AIzaSyADZ6Uq-pFQIWMdkGeh7JIozEY7jJM6r_I";
  static String messagingSenderId = "634480644405";
  static String projectId = "chatappflutter-13318";
  final primaryColor = const Color(0xFFee7b64);
}
